import Image from 'next/image'
import styled from 'styled-components'
import htmllogo from '../public/images/techLogos/htmllogo.png'
import css from '../public/images/techLogos/css.png'
import jslogo from '../public/images/techLogos/javascript.png'
import react from '../public/images/techLogos/react.png'
import bootstrap from '../public/images/techLogos/bootstrap.png'
import sass from '../public/images/techLogos/sass.png'
import wordpress from '../public/images/techLogos/wordpress.png'
import git from '../public/images/techLogos/git.png'

const Wrap = styled.div`
	display: grid;
	grid-template-columns: repeat(auto-fill, minmax(auto, 96px));
	gap: 4em;
	justify-content: center;
	margin: 0 auto 5em auto;
	max-width: 720px;
`

export default function TechLogos() {
	return (
		<Wrap>
			<Image src={htmllogo} alt='HTML logo' layout='fixed' />
			<Image src={css} alt='CSS logo' layout='fixed' />
			<Image src={jslogo} alt='CSS logo' layout='fixed' />
			<Image src={react} alt='React logo' layout='fixed' />
			<Image src={bootstrap} alt='Bootstrap logo' layout='fixed' />
			<Image src={sass} alt='Sass logo' layout='fixed' />
			<Image src={wordpress} alt='WordPress logo' layout='fixed' />
			<Image src={git} alt='Git logo' layout='fixed' />
		</Wrap>
	)
}
