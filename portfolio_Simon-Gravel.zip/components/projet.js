import Link from 'next/link';
import styled from 'styled-components';

const Wrap = styled.div`
	width: 320px;
	height: 320px;
	background-color: ${(props) => props.theme.darkaccent};
	padding: 1em;
	border-radius: 4px;
`;

const TechWrap = styled.div`
	display: flex;
	flex-wrap: wrap;
	gap: 20px;
`;

const Tech = styled.div`
	font-weight: 500;
	border: 1px solid ${(props) => props.theme.lightshades};
	padding: 0.5em;
	border-radius: 4px;
`;

export default function Projet({ titre, date, description, tech, lien }) {
	return (
		<Wrap>
			<h2>{titre}</h2>
			<span>{date}</span>
			<p>{description}</p>
			<TechWrap>
				{tech.map((i) => (
					<Tech key={i}>{i}</Tech>
				))}
			</TechWrap>
			<Link href={`./projets/${lien}`}>
				<a>Lire la suite &gt;</a>
			</Link>
		</Wrap>
	);
}
