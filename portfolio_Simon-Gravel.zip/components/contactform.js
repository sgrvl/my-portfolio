import styled from 'styled-components'

const Form = styled.form`
	display: flex;
	flex-direction: column;
	margin: 0 auto;
	max-width: 720px;

	label {
		color: ${(props) => props.theme.darkshades};
	}

	input,
	textarea {
		border: none;
		border-radius: 4px;
		background-color: #eaeaeb;
		margin: 1em 0 2em 0;
		padding: 1em;

		&:focus {
			outline-color: ${(props) => props.theme.main};
		}
	}
`

const Button = styled.button`
	width: max-content;
	background-color: transparent;
	border: 2px solid ${(props) => props.theme.darkshades};
	border-radius: 4px;
	font-family: 'Merriweather', serif;
	font-size: 1.5em;
	padding: 0.25em 1.5em;
	margin: 0 auto;
`

export default function ContactForm() {
	return (
		<Form action=''>
			<label htmlFor='nom' required>
				Nom*
			</label>
			<input type='text' />
			<label htmlFor='courriel' required>
				Courriel*
			</label>
			<input type='email' name='email' id='email' />
			<label htmlFor='message' required>
				Message*
			</label>
			<textarea name='message' id='message' rows='10'></textarea>
			<Button type='submit'>Envoyer</Button>
		</Form>
	)
}
