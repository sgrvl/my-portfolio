import Image from 'next/image';
import Link from 'next/link';
import styled from 'styled-components';

const Wrap = styled.div`
	/* display: flex; */
	justify-content: center;
	padding-bottom: 100px;
	position: relative;
	margin-bottom: 6em;
`;

const ImageWrap = styled.div`
	@media (min-width: 768px) {
		padding-right: 100px;
	}
`;

const Content = styled.div`
	position: absolute;
	bottom: 0;
	right: 100px;
	z-index: 20;
	border-radius: 4px;
	padding: 2em;
	background-color: ${(props) => props.theme.darkshades};
	width: 65%;
`;

const ContentText = styled.div`
	color: ${(props) => props.theme.lightshades};
	margin-bottom: 1em;

	h3 {
		margin: 0;
		font-size: 2em;
	}

	span {
		color: ${(props) => props.theme.lightaccent};
		font-family: 'Merriweather', serif;
		font-weight: 400;
	}

	p {
		font-weight: 400;
	}
`;

const LinkMore = styled.a`
	font-weight: 400;
	display: flex;
	justify-content: flex-end;
	text-decoration: underline;

	&:hover,
	&:visited:hover,
	&:focus,
	&:active {
		color: ${(props) => props.theme.lightaccent};
	}

	&:visited,
	&:link {
		color: ${(props) => props.theme.main};
	}
`;

const TechWrap = styled.div`
	display: flex;
	gap: 20px;
`;

const Tech = styled.div`
	font-weight: 500;
	border: 1px solid ${(props) => props.theme.lightshades};
	padding: 0.5em;
	border-radius: 4px;
`;

export default function Projet({ image, alt, title, date, text, tech, link }) {
	return (
		<Wrap>
			<ImageWrap>
				<Image src={image} alt={alt} />
			</ImageWrap>
			<Content>
				<ContentText>
					<h3>{title}</h3>
					<span>{date}</span>
					<p>{text}</p>
					<TechWrap>
						{tech.map((i) => (
							<Tech key={i}>{i}</Tech>
						))}
					</TechWrap>
				</ContentText>

				<Link href={link} passHref>
					<LinkMore>Lire la suite &gt; </LinkMore>
				</Link>
			</Content>
		</Wrap>
	);
}

/*

div
    img
    div
        titre
        date
        paragraphe
        techs
        lien
div

*/
