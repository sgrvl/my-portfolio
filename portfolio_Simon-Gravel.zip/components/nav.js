import Link from 'next/link'
import styled from 'styled-components'
import Logo from './logo'

const Navbar = styled.header`
	width: 100%;
	height: 100px;
	display: flex;
	justify-content: space-between;
	padding-top: 1em;

	a {
		text-decoration: none;
	}
`

const Links = styled.ul`
	list-style: none;
	display: flex;
	color: ${(props) => props.theme.darkshades};
	gap: 40px;

	a {
		text-decoration: none;

		&:hover,
		&:visited:hover,
		&:focus,
		&:active {
			color: ${(props) => props.theme.main};
			text-decoration: underline;
		}

		&:visited {
			color: inherit;
		}
	}
`

export default function Nav() {
	return (
		<Navbar className='container'>
			<Link href='/' passHref>
				<a>
					<Logo />
				</a>
			</Link>

			<Links>
				<Link href='/' passHref>
					<a>Accueil</a>
				</Link>
				<Link href='/projets' passHref>
					<a>Projets</a>
				</Link>
				<Link href='/' passHref>
					<a>CV</a>
				</Link>
			</Links>
		</Navbar>
	)
}
