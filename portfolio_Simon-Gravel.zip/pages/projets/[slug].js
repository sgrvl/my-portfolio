import { useRouter } from 'next/router';

export default function PageProjet() {
	const router = useRouter();
	const { slug } = router.query;

	return (
		<div className='container'>
			<h1>{slug}</h1>
		</div>
	);
}
